#!/usr/bin/env python3
"""
Customer Churn Prediction Backend API Test Suite
Tests all endpoints and functionality for the churn prediction system.
"""

import requests
import json
import time
from datetime import datetime
import sys

# Backend URL from environment
BACKEND_URL = "https://churnanalytics.preview.emergentagent.com/api"

class ChurnAPITester:
    def __init__(self):
        self.session = requests.Session()
        self.test_results = []
        
    def log_test(self, test_name, success, message, response_data=None):
        """Log test results"""
        result = {
            "test": test_name,
            "success": success,
            "message": message,
            "timestamp": datetime.now().isoformat(),
            "response_data": response_data
        }
        self.test_results.append(result)
        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{status} {test_name}: {message}")
        if response_data and not success:
            print(f"   Response: {response_data}")
    
    def test_health_check(self):
        """Test GET /api/ endpoint"""
        try:
            response = self.session.get(f"{BACKEND_URL}/")
            if response.status_code == 200:
                data = response.json()
                if "message" in data:
                    self.log_test("Health Check", True, f"API is running - {data['message']}")
                    return True
                else:
                    self.log_test("Health Check", False, "Response missing 'message' field", data)
                    return False
            else:
                self.log_test("Health Check", False, f"HTTP {response.status_code}", response.text)
                return False
        except Exception as e:
            self.log_test("Health Check", False, f"Connection error: {str(e)}")
            return False
    
    def test_analytics_endpoint(self):
        """Test GET /api/analytics endpoint"""
        try:
            response = self.session.get(f"{BACKEND_URL}/analytics")
            if response.status_code == 200:
                data = response.json()
                required_fields = ["total_predictions", "risk_distribution", "churn_trend", "average_churn_probability"]
                
                missing_fields = [field for field in required_fields if field not in data]
                if missing_fields:
                    self.log_test("Analytics Endpoint", False, f"Missing fields: {missing_fields}", data)
                    return False
                
                # Check risk_distribution structure
                risk_dist = data.get("risk_distribution", {})
                risk_fields = ["high_risk", "medium_risk", "low_risk"]
                missing_risk_fields = [field for field in risk_fields if field not in risk_dist]
                
                if missing_risk_fields:
                    self.log_test("Analytics Endpoint", False, f"Missing risk distribution fields: {missing_risk_fields}", data)
                    return False
                
                self.log_test("Analytics Endpoint", True, f"Analytics data retrieved successfully - {data['total_predictions']} total predictions")
                return True
            else:
                self.log_test("Analytics Endpoint", False, f"HTTP {response.status_code}", response.text)
                return False
        except Exception as e:
            self.log_test("Analytics Endpoint", False, f"Error: {str(e)}")
            return False
    
    def test_customer_prediction(self):
        """Test POST /api/predict with sample customer data"""
        sample_customer = {
            "customer_id": "TEST001",
            "gender": "Male",
            "senior_citizen": 0,
            "partner": "No",
            "dependents": "No",
            "tenure": 5,
            "phone_service": "Yes",
            "multiple_lines": "No",
            "internet_service": "Fiber optic",
            "online_security": "No",
            "online_backup": "Yes",
            "device_protection": "No",
            "tech_support": "No",
            "streaming_tv": "No",
            "streaming_movies": "Yes",
            "contract": "Month-to-month",
            "paperless_billing": "Yes",
            "payment_method": "Electronic check",
            "monthly_charges": 85.5,
            "total_charges": 500.0
        }
        
        try:
            response = self.session.post(f"{BACKEND_URL}/predict", json=sample_customer)
            if response.status_code == 200:
                data = response.json()
                required_fields = ["churn_probability", "churn_prediction", "risk_level", "retention_strategies", "confidence"]
                
                missing_fields = [field for field in required_fields if field not in data]
                if missing_fields:
                    self.log_test("Customer Prediction", False, f"Missing fields: {missing_fields}", data)
                    return False
                
                # Validate data types and ranges
                if not (0 <= data["churn_probability"] <= 1):
                    self.log_test("Customer Prediction", False, f"Invalid churn_probability: {data['churn_probability']}", data)
                    return False
                
                if data["churn_prediction"] not in ["Will Churn", "Will Stay"]:
                    self.log_test("Customer Prediction", False, f"Invalid churn_prediction: {data['churn_prediction']}", data)
                    return False
                
                if data["risk_level"] not in ["High Risk", "Medium Risk", "Low Risk"]:
                    self.log_test("Customer Prediction", False, f"Invalid risk_level: {data['risk_level']}", data)
                    return False
                
                if not isinstance(data["retention_strategies"], list) or len(data["retention_strategies"]) == 0:
                    self.log_test("Customer Prediction", False, "retention_strategies should be non-empty list", data)
                    return False
                
                self.log_test("Customer Prediction", True, 
                            f"Prediction successful - Probability: {data['churn_probability']:.3f}, Risk: {data['risk_level']}, Strategies: {len(data['retention_strategies'])}")
                return True
            else:
                self.log_test("Customer Prediction", False, f"HTTP {response.status_code}", response.text)
                return False
        except Exception as e:
            self.log_test("Customer Prediction", False, f"Error: {str(e)}")
            return False
    
    def test_customer_storage(self):
        """Test POST /api/customers and GET /api/customers"""
        # Test customer creation
        test_customer = {
            "customer_id": "STORAGE_TEST_001",
            "gender": "Female",
            "senior_citizen": 1,
            "partner": "Yes",
            "dependents": "Yes",
            "tenure": 24,
            "phone_service": "Yes",
            "multiple_lines": "Yes",
            "internet_service": "DSL",
            "online_security": "Yes",
            "online_backup": "No",
            "device_protection": "Yes",
            "tech_support": "Yes",
            "streaming_tv": "Yes",
            "streaming_movies": "No",
            "contract": "Two year",
            "paperless_billing": "No",
            "payment_method": "Credit card (automatic)",
            "monthly_charges": 65.25,
            "total_charges": 1565.0
        }
        
        try:
            # Test POST /api/customers
            response = self.session.post(f"{BACKEND_URL}/customers", json=test_customer)
            if response.status_code == 200:
                created_customer = response.json()
                required_fields = ["id", "customer_id", "created_at"]
                
                missing_fields = [field for field in required_fields if field not in created_customer]
                if missing_fields:
                    self.log_test("Customer Storage - Create", False, f"Missing fields in created customer: {missing_fields}", created_customer)
                    return False
                
                if created_customer["customer_id"] != test_customer["customer_id"]:
                    self.log_test("Customer Storage - Create", False, "Customer ID mismatch", created_customer)
                    return False
                
                self.log_test("Customer Storage - Create", True, f"Customer created successfully with ID: {created_customer['id']}")
                
                # Test GET /api/customers
                time.sleep(1)  # Brief delay to ensure data is stored
                response = self.session.get(f"{BACKEND_URL}/customers")
                if response.status_code == 200:
                    customers = response.json()
                    if not isinstance(customers, list):
                        self.log_test("Customer Storage - Retrieve", False, "Response should be a list", customers)
                        return False
                    
                    # Check if our test customer is in the list
                    found_customer = None
                    for customer in customers:
                        if customer.get("customer_id") == "STORAGE_TEST_001":
                            found_customer = customer
                            break
                    
                    if found_customer:
                        self.log_test("Customer Storage - Retrieve", True, f"Retrieved {len(customers)} customers, including our test customer")
                        return True
                    else:
                        self.log_test("Customer Storage - Retrieve", False, f"Test customer not found in {len(customers)} retrieved customers")
                        return False
                else:
                    self.log_test("Customer Storage - Retrieve", False, f"HTTP {response.status_code}", response.text)
                    return False
            else:
                self.log_test("Customer Storage - Create", False, f"HTTP {response.status_code}", response.text)
                return False
        except Exception as e:
            self.log_test("Customer Storage", False, f"Error: {str(e)}")
            return False
    
    def test_predictions_history(self):
        """Test GET /api/predictions to retrieve prediction history"""
        try:
            response = self.session.get(f"{BACKEND_URL}/predictions")
            if response.status_code == 200:
                predictions = response.json()
                if not isinstance(predictions, list):
                    self.log_test("Predictions History", False, "Response should be a list", predictions)
                    return False
                
                # If we have predictions, validate structure
                if len(predictions) > 0:
                    sample_prediction = predictions[0]
                    required_fields = ["id", "customer_id", "churn_probability", "churn_prediction", "risk_level", "retention_strategies", "predicted_at"]
                    
                    missing_fields = [field for field in required_fields if field not in sample_prediction]
                    if missing_fields:
                        self.log_test("Predictions History", False, f"Missing fields in prediction: {missing_fields}", sample_prediction)
                        return False
                
                self.log_test("Predictions History", True, f"Retrieved {len(predictions)} prediction records")
                return True
            else:
                self.log_test("Predictions History", False, f"HTTP {response.status_code}", response.text)
                return False
        except Exception as e:
            self.log_test("Predictions History", False, f"Error: {str(e)}")
            return False
    
    def test_error_handling(self):
        """Test error handling with invalid data"""
        # Test 1: Missing required fields
        invalid_customer = {
            "customer_id": "INVALID_TEST",
            "gender": "Male"
            # Missing many required fields
        }
        
        try:
            response = self.session.post(f"{BACKEND_URL}/predict", json=invalid_customer)
            if response.status_code in [400, 422, 500]:  # Expected error codes
                self.log_test("Error Handling - Missing Fields", True, f"Properly handled missing fields with HTTP {response.status_code}")
            else:
                self.log_test("Error Handling - Missing Fields", False, f"Unexpected response for invalid data: HTTP {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Error Handling - Missing Fields", False, f"Error: {str(e)}")
            return False
        
        # Test 2: Invalid data types
        invalid_types_customer = {
            "customer_id": "INVALID_TYPES",
            "gender": "Male",
            "senior_citizen": "invalid",  # Should be int
            "partner": "No",
            "dependents": "No",
            "tenure": "invalid",  # Should be int
            "phone_service": "Yes",
            "multiple_lines": "No",
            "internet_service": "DSL",
            "online_security": "No",
            "online_backup": "No",
            "device_protection": "No",
            "tech_support": "No",
            "streaming_tv": "No",
            "streaming_movies": "No",
            "contract": "Month-to-month",
            "paperless_billing": "Yes",
            "payment_method": "Electronic check",
            "monthly_charges": "invalid",  # Should be float
            "total_charges": "invalid"  # Should be float
        }
        
        try:
            response = self.session.post(f"{BACKEND_URL}/predict", json=invalid_types_customer)
            if response.status_code in [400, 422, 500]:  # Expected error codes
                self.log_test("Error Handling - Invalid Types", True, f"Properly handled invalid data types with HTTP {response.status_code}")
                return True
            else:
                self.log_test("Error Handling - Invalid Types", False, f"Unexpected response for invalid types: HTTP {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Error Handling - Invalid Types", False, f"Error: {str(e)}")
            return False
    
    def run_all_tests(self):
        """Run all tests in sequence"""
        print(f"🚀 Starting Customer Churn Prediction API Tests")
        print(f"📡 Backend URL: {BACKEND_URL}")
        print("=" * 60)
        
        tests = [
            ("Health Check", self.test_health_check),
            ("Analytics Endpoint", self.test_analytics_endpoint),
            ("Customer Prediction", self.test_customer_prediction),
            ("Customer Storage", self.test_customer_storage),
            ("Predictions History", self.test_predictions_history),
            ("Error Handling", self.test_error_handling)
        ]
        
        passed = 0
        total = len(tests)
        
        for test_name, test_func in tests:
            print(f"\n🧪 Running {test_name}...")
            try:
                if test_func():
                    passed += 1
            except Exception as e:
                self.log_test(test_name, False, f"Test execution error: {str(e)}")
        
        print("\n" + "=" * 60)
        print(f"📊 Test Results: {passed}/{total} tests passed")
        
        if passed == total:
            print("🎉 All tests passed! Backend API is working correctly.")
            return True
        else:
            print(f"⚠️  {total - passed} test(s) failed. Check the details above.")
            return False
    
    def get_summary(self):
        """Get a summary of test results"""
        total_tests = len(self.test_results)
        passed_tests = sum(1 for result in self.test_results if result["success"])
        failed_tests = total_tests - passed_tests
        
        summary = {
            "total_tests": total_tests,
            "passed": passed_tests,
            "failed": failed_tests,
            "success_rate": (passed_tests / total_tests * 100) if total_tests > 0 else 0,
            "details": self.test_results
        }
        
        return summary

def main():
    """Main test execution"""
    tester = ChurnAPITester()
    success = tester.run_all_tests()
    
    # Print detailed summary
    summary = tester.get_summary()
    print(f"\n📈 Success Rate: {summary['success_rate']:.1f}%")
    
    # Print failed tests details
    failed_tests = [test for test in summary['details'] if not test['success']]
    if failed_tests:
        print("\n❌ Failed Tests Details:")
        for test in failed_tests:
            print(f"  - {test['test']}: {test['message']}")
    
    return success

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)