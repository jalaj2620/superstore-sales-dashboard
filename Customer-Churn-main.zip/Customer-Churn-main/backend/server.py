from fastapi import FastAPI, APIRouter, HTTPException, UploadFile, File
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
import pandas as pd
import numpy as np
from pathlib import Path
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
import uuid
from datetime import datetime, timezone
import json
import pickle
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder, StandardScaler
import io

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create the main app without a prefix
app = FastAPI()

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# Global variables for ML model and preprocessing
model = None
scaler = None
label_encoders = {}

# Initialize ML model and sample data
def initialize_ml_model():
    global model, scaler, label_encoders
    
    # Create sample Telco Customer Churn dataset
    sample_data = {
        'customerID': [f'CUST{i:04d}' for i in range(1000)],
        'gender': np.random.choice(['Male', 'Female'], 1000),
        'SeniorCitizen': np.random.choice([0, 1], 1000),
        'Partner': np.random.choice(['Yes', 'No'], 1000),
        'Dependents': np.random.choice(['Yes', 'No'], 1000),
        'tenure': np.random.randint(1, 73, 1000),
        'PhoneService': np.random.choice(['Yes', 'No'], 1000),
        'MultipleLines': np.random.choice(['Yes', 'No', 'No phone service'], 1000),
        'InternetService': np.random.choice(['DSL', 'Fiber optic', 'No'], 1000),
        'OnlineSecurity': np.random.choice(['Yes', 'No', 'No internet service'], 1000),
        'OnlineBackup': np.random.choice(['Yes', 'No', 'No internet service'], 1000),
        'DeviceProtection': np.random.choice(['Yes', 'No', 'No internet service'], 1000),
        'TechSupport': np.random.choice(['Yes', 'No', 'No internet service'], 1000),
        'StreamingTV': np.random.choice(['Yes', 'No', 'No internet service'], 1000),
        'StreamingMovies': np.random.choice(['Yes', 'No', 'No internet service'], 1000),
        'Contract': np.random.choice(['Month-to-month', 'One year', 'Two year'], 1000),
        'PaperlessBilling': np.random.choice(['Yes', 'No'], 1000),
        'PaymentMethod': np.random.choice(['Electronic check', 'Mailed check', 'Bank transfer (automatic)', 'Credit card (automatic)'], 1000),
        'MonthlyCharges': np.random.uniform(18.25, 118.75, 1000),
        'TotalCharges': np.random.uniform(18.8, 8684.8, 1000)
    }
    
    df = pd.DataFrame(sample_data)
    
    # Create churn based on logical rules (for realistic data)
    churn_prob = np.zeros(1000)
    churn_prob += (df['Contract'] == 'Month-to-month') * 0.4
    churn_prob += (df['tenure'] < 12) * 0.3
    churn_prob += (df['MonthlyCharges'] > 80) * 0.2
    churn_prob += (df['InternetService'] == 'Fiber optic') * 0.1
    churn_prob += (df['PaymentMethod'] == 'Electronic check') * 0.15
    
    # Ensure probabilities are within [0, 1] range
    churn_prob = np.clip(churn_prob, 0, 1)
    
    df['Churn'] = np.random.binomial(1, churn_prob)
    
    # Prepare features for model training
    features_to_encode = ['gender', 'Partner', 'Dependents', 'PhoneService', 'MultipleLines',
                         'InternetService', 'OnlineSecurity', 'OnlineBackup', 'DeviceProtection',
                         'TechSupport', 'StreamingTV', 'StreamingMovies', 'Contract',
                         'PaperlessBilling', 'PaymentMethod']
    
    features_to_scale = ['tenure', 'MonthlyCharges', 'TotalCharges']
    
    # Encode categorical variables
    df_encoded = df.copy()
    label_encoders = {}
    
    for feature in features_to_encode:
        le = LabelEncoder()
        df_encoded[feature] = le.fit_transform(df[feature])
        label_encoders[feature] = le
    
    # Scale numerical features
    scaler = StandardScaler()
    df_encoded[features_to_scale] = scaler.fit_transform(df[features_to_scale])
    
    # Prepare training data
    X = df_encoded.drop(['customerID', 'Churn'], axis=1)
    y = df_encoded['Churn']
    
    # Train model
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X, y)
    
    return df

# Define Models
class Customer(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    customer_id: str
    gender: str
    senior_citizen: int
    partner: str
    dependents: str
    tenure: int
    phone_service: str
    multiple_lines: str
    internet_service: str
    online_security: str
    online_backup: str
    device_protection: str
    tech_support: str
    streaming_tv: str
    streaming_movies: str
    contract: str
    paperless_billing: str
    payment_method: str
    monthly_charges: float
    total_charges: float
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class CustomerCreate(BaseModel):
    customer_id: str
    gender: str
    senior_citizen: int
    partner: str
    dependents: str
    tenure: int
    phone_service: str
    multiple_lines: str
    internet_service: str
    online_security: str
    online_backup: str
    device_protection: str
    tech_support: str
    streaming_tv: str
    streaming_movies: str
    contract: str
    paperless_billing: str
    payment_method: str
    monthly_charges: float
    total_charges: float

class ChurnPrediction(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    customer_id: str
    churn_probability: float
    churn_prediction: str
    risk_level: str
    retention_strategies: List[str]
    predicted_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class PredictionResponse(BaseModel):
    churn_probability: float
    churn_prediction: str
    risk_level: str
    retention_strategies: List[str]
    confidence: float

def generate_retention_strategies(customer_data: dict, churn_prob: float) -> List[str]:
    """Generate rule-based retention strategies"""
    strategies = []
    
    if churn_prob > 0.7:
        strategies.append("🎯 High Priority: Immediate intervention required")
        strategies.append("💰 Offer 25% discount for next 6 months")
        strategies.append("📞 Schedule urgent customer service call")
    
    if customer_data.get('contract') == 'Month-to-month':
        strategies.append("📋 Offer contract upgrade with incentives")
        strategies.append("🎁 Provide loyalty rewards for annual commitment")
    
    if customer_data.get('tenure', 0) < 12:
        strategies.append("👋 Welcome program for new customers")
        strategies.append("📚 Provide onboarding tutorials and support")
    
    if customer_data.get('monthly_charges', 0) > 80:
        strategies.append("💸 Review pricing plan - consider downgrade options")
        strategies.append("📊 Show value comparison with competitor pricing")
    
    if customer_data.get('tech_support') == 'No':
        strategies.append("🛠️ Offer free tech support for 3 months")
    
    if customer_data.get('payment_method') == 'Electronic check':
        strategies.append("💳 Incentivize automatic payment methods")
        strategies.append("🎁 Offer $10 credit for switching to auto-pay")
    
    if customer_data.get('internet_service') == 'Fiber optic' and churn_prob > 0.5:
        strategies.append("🚀 Highlight premium service benefits")
        strategies.append("📺 Offer streaming service bundle discount")
    
    if not strategies:
        strategies.append("😊 Customer appears satisfied - maintain current service level")
        strategies.append("📩 Send quarterly satisfaction survey")
    
    return strategies[:6]  # Limit to 6 strategies

def preprocess_customer_data(customer_data: dict) -> np.ndarray:
    """Preprocess customer data for prediction"""
    global label_encoders, scaler
    
    # Create DataFrame from input and map field names to match training data
    df = pd.DataFrame([customer_data])
    
    # Map API field names to model field names
    field_mapping = {
        'gender': 'gender',
        'senior_citizen': 'SeniorCitizen',
        'partner': 'Partner',
        'dependents': 'Dependents',
        'tenure': 'tenure',
        'phone_service': 'PhoneService',
        'multiple_lines': 'MultipleLines',
        'internet_service': 'InternetService',
        'online_security': 'OnlineSecurity',
        'online_backup': 'OnlineBackup',
        'device_protection': 'DeviceProtection',
        'tech_support': 'TechSupport',
        'streaming_tv': 'StreamingTV',
        'streaming_movies': 'StreamingMovies',
        'contract': 'Contract',
        'paperless_billing': 'PaperlessBilling',
        'payment_method': 'PaymentMethod',
        'monthly_charges': 'MonthlyCharges',
        'total_charges': 'TotalCharges'
    }
    
    # Rename columns to match training data
    df = df.rename(columns=field_mapping)
    
    # Encode categorical variables
    features_to_encode = ['gender', 'Partner', 'Dependents', 'PhoneService', 'MultipleLines',
                         'InternetService', 'OnlineSecurity', 'OnlineBackup', 'DeviceProtection',
                         'TechSupport', 'StreamingTV', 'StreamingMovies', 'Contract',
                         'PaperlessBilling', 'PaymentMethod']
    
    for feature in features_to_encode:
        if feature in df.columns and feature in label_encoders:
            try:
                df[feature] = label_encoders[feature].transform(df[feature])
            except ValueError:
                # Handle unseen categories
                df[feature] = 0
    
    # Scale numerical features
    features_to_scale = ['tenure', 'MonthlyCharges', 'TotalCharges']
    df[features_to_scale] = scaler.transform(df[features_to_scale])
    
    # Ensure all features are present and in correct order (matching training data)
    feature_columns = ['gender', 'SeniorCitizen', 'Partner', 'Dependents', 'tenure', 'PhoneService',
                      'MultipleLines', 'InternetService', 'OnlineSecurity', 'OnlineBackup',
                      'DeviceProtection', 'TechSupport', 'StreamingTV', 'StreamingMovies',
                      'Contract', 'PaperlessBilling', 'PaymentMethod', 'MonthlyCharges', 'TotalCharges']
    
    return df[feature_columns].values

# API Routes
@api_router.get("/")
async def root():
    return {"message": "Customer Churn Prediction API"}

@api_router.post("/customers", response_model=Customer)
async def create_customer(customer: CustomerCreate):
    customer_dict = customer.dict()
    customer_obj = Customer(**customer_dict)
    await db.customers.insert_one(customer_obj.dict())
    return customer_obj

@api_router.get("/customers", response_model=List[Customer])
async def get_customers():
    customers = await db.customers.find().to_list(1000)
    return [Customer(**customer) for customer in customers]

@api_router.post("/predict", response_model=PredictionResponse)
async def predict_churn(customer: CustomerCreate):
    global model
    
    if model is None:
        raise HTTPException(status_code=500, detail="Model not initialized")
    
    try:
        # Convert customer data for prediction
        customer_dict = customer.dict()
        
        # Preprocess data
        processed_data = preprocess_customer_data(customer_dict)
        
        # Make prediction
        churn_prob = model.predict_proba(processed_data)[0][1]  # Probability of churn
        churn_prediction = "Will Churn" if churn_prob > 0.5 else "Will Stay"
        
        # Determine risk level
        if churn_prob > 0.7:
            risk_level = "High Risk"
        elif churn_prob > 0.4:
            risk_level = "Medium Risk"
        else:
            risk_level = "Low Risk"
        
        # Generate retention strategies
        retention_strategies = generate_retention_strategies(customer_dict, churn_prob)
        
        # Calculate confidence
        confidence = max(churn_prob, 1 - churn_prob)
        
        # Save prediction to database
        prediction = ChurnPrediction(
            customer_id=customer.customer_id,
            churn_probability=float(churn_prob),
            churn_prediction=churn_prediction,
            risk_level=risk_level,
            retention_strategies=retention_strategies
        )
        await db.predictions.insert_one(prediction.dict())
        
        return PredictionResponse(
            churn_probability=float(churn_prob),
            churn_prediction=churn_prediction,
            risk_level=risk_level,
            retention_strategies=retention_strategies,
            confidence=float(confidence)
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Prediction error: {str(e)}")

@api_router.get("/predictions", response_model=List[ChurnPrediction])
async def get_predictions():
    predictions = await db.predictions.find().sort("predicted_at", -1).to_list(1000)
    return [ChurnPrediction(**prediction) for prediction in predictions]

@api_router.get("/analytics")
async def get_analytics():
    try:
        # Get prediction statistics
        total_predictions = await db.predictions.count_documents({})
        high_risk_count = await db.predictions.count_documents({"risk_level": "High Risk"})
        medium_risk_count = await db.predictions.count_documents({"risk_level": "Medium Risk"})
        low_risk_count = await db.predictions.count_documents({"risk_level": "Low Risk"})
        
        # Get recent predictions for trend analysis
        recent_predictions = await db.predictions.find().sort("predicted_at", -1).limit(100).to_list(100)
        
        churn_trend = []
        for pred in recent_predictions:
            churn_trend.append({
                "date": pred["predicted_at"].isoformat(),
                "churn_probability": pred["churn_probability"],
                "risk_level": pred["risk_level"]
            })
        
        return {
            "total_predictions": total_predictions,
            "risk_distribution": {
                "high_risk": high_risk_count,
                "medium_risk": medium_risk_count,
                "low_risk": low_risk_count
            },
            "churn_trend": churn_trend,
            "average_churn_probability": sum([p["churn_probability"] for p in recent_predictions]) / len(recent_predictions) if recent_predictions else 0
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Analytics error: {str(e)}")

@api_router.post("/batch-predict")
async def batch_predict(file: UploadFile = File(...)):
    try:
        # Read CSV file
        content = await file.read()
        df = pd.read_csv(io.StringIO(content.decode('utf-8')))
        
        predictions = []
        for _, row in df.iterrows():
            customer_data = row.to_dict()
            
            # Preprocess and predict
            processed_data = preprocess_customer_data(customer_data)
            churn_prob = model.predict_proba(processed_data)[0][1]
            churn_prediction = "Will Churn" if churn_prob > 0.5 else "Will Stay"
            
            # Determine risk level
            if churn_prob > 0.7:
                risk_level = "High Risk"
            elif churn_prob > 0.4:
                risk_level = "Medium Risk"
            else:
                risk_level = "Low Risk"
            
            predictions.append({
                "customer_id": customer_data.get("customer_id", f"BATCH_{len(predictions)}"),
                "churn_probability": float(churn_prob),
                "churn_prediction": churn_prediction,
                "risk_level": risk_level,
                "retention_strategies": generate_retention_strategies(customer_data, churn_prob)
            })
        
        # Save batch predictions
        for pred in predictions:
            prediction_obj = ChurnPrediction(**pred)
            await db.predictions.insert_one(prediction_obj.dict())
        
        return {
            "message": f"Successfully processed {len(predictions)} customers",
            "predictions": predictions
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Batch prediction error: {str(e)}")

# Initialize ML model on startup
sample_df = initialize_ml_model()

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()